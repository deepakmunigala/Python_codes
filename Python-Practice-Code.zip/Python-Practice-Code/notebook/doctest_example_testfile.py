import doctest
doctest.testfile('doctest_text.txt')
