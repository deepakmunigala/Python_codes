import math

print(math.ulp(0.0))
# 5e-324

print(format(math.ulp(0.0), '.17'))
# 4.9406564584124654e-324
