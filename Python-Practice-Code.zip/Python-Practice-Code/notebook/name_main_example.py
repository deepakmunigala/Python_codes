import math
import numpy as np

print(math.__name__)
# math

print(np.__name__)
# numpy

import hello

print(hello.__name__)
# hello

hello.func()
# Hello!
# __name__ is hello
