print(len([0, 1, 2]))
# 3

print(abs(-10))
# 10
