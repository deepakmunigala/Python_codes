import numpy as np

print(np.inf)
# inf

print(type(np.inf))
# <class 'float'>

print(float('inf') == np.inf)
# True
