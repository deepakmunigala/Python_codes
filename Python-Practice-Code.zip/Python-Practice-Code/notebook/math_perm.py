import math

print(math.perm(4, 2))
# 12

print(math.perm(4, 4))
# 24

# print(math.perm(4.5, 2.5))
# TypeError: 'float' object cannot be interpreted as an integer

# print(math.perm(-4, -2))
# ValueError: n must be a non-negative integer
