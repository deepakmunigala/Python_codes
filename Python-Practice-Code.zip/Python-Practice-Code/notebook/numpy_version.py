import numpy as np

print(np.__version__)
# 1.14.1

print(np.version.version)
# 1.14.1

print(np.version.short_version)
# 1.14.1

print(np.version.full_version)
# 1.14.1

print(np.version.git_revision)
# 7dcee7a469ad1bbfef1cd8980dc18bf5869c5391

print(np.version.release)
# True
