import numpy as np

arr = np.array([[0, 1], [2, 3]])

det = np.linalg.det(arr)
print(det)
# -2.0
