import math

print(math.inf)
# inf

print(type(math.inf))
# <class 'float'>

print(float('inf') == math.inf)
# True
