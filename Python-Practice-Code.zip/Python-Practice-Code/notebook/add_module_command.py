import sys
import add_module

print(add_module.add(float(sys.argv[1]), float(sys.argv[2])))
