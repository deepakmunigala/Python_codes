def func():
    print('Hello!')
    print('__name__ is', __name__)


if __name__ == '__main__':
    func()
