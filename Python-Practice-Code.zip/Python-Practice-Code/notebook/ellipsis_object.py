print(Ellipsis)
# Ellipsis

print(...)
# Ellipsis

print(type(Ellipsis))
# <class 'ellipsis'>

print(type(...))
# <class 'ellipsis'>

print(Ellipsis is ...)
# True
